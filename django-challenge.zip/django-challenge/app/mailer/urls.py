#-*- coding: utf-8 -*-
from django.conf.urls import include, url
from django.views.decorators.cache import cache_page
from django.conf import settings
from django.core.cache.backends.base import DEFAULT_TIMEOUT


CACHE_TTL = getattr(settings, 'CACHE_TTL', DEFAULT_TIMEOUT)

from mailer.views import IndexView

urlpatterns = [
    url(r'^$', cache_page(CACHE_TTL)(IndexView.as_view()), name="index"),
]
