#comment the below lines in production
import pymysql

pymysql.install_as_MySQLdb()